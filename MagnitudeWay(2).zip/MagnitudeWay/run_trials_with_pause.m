%% ====== Trial-based Measurement Script (4 errors per trial) ======
clear; clc;

%% ====== User Parameters ======
num_trials = 30;                  % Number of trials
wait_time  = 120;                 % Interval between each trial (in seconds)
excel_file = 'error_log.xlsx';    % Output file
sheet_name = 'Trials';            % Data sheet
sheet_sum  = 'Summary';           % Summary sheet

%% ====== Initialize Storage ======
errors     = nan(num_trials, 4);  % One trial per row; columns = [e6 e8 e12 e14]
timestamps = strings(num_trials,1);

%% ====== Main Loop ======
for i = 1:num_trials
    fprintf('\n=== Trial %d of %d ===\n', i, num_trials);

    % One measurement: Returns [e6 e8 e12 e14]
    e = measure_once();                  % 1x4
    errors(i,:)  = e;
    timestamps(i) = string(datetime('now','Format','yyyy-MM-dd HH:mm:ss'));

    % Append to Excel (overwrite from row 1 for easy viewing)
    T = table((1:i)', timestamps(1:i), ...
              errors(1:i,1), errors(1:i,2), errors(1:i,3), errors(1:i,4), ...
              'VariableNames', {'Trial','Timestamp','e6','e8','e12','e14'});
    writetable(T, excel_file, 'Sheet', sheet_name, 'Range', 'A1');

    fprintf('Trial %d finished: [e6=%.4f, e8=%.4f, e12=%.4f, e14=%.4f]\n', ...
            i, e(1), e(2), e(3), e(4));

    if i < num_trials
        fprintf('Waiting %.0f seconds before next trial...\n', wait_time);
        pause(wait_time);
    end
end

%% ====== Between-trial statistics (per config) ======
mean_across = mean(errors, 1, 'omitnan');          % 1x4
std_across  = std( errors, 0, 1, 'omitnan');       % 1x4 (N-1)

fprintf('\nFinal results across %d trials:\n', num_trials);
fprintf('Mean: [e6=%.4f, e8=%.4f, e12=%.4f, e14=%.4f]\n', mean_across);
fprintf('Std : [s6=%.4f, s8=%.4f, s12=%.4f, s14=%.4f]\n',  std_across);

%% ====== Save summary ======
S = table(mean_across.', std_across.', ...
          'VariableNames', {'Mean','Std'}, ...
          'RowNames', {'cfg6','cfg8','cfg12','cfg14'});
writetable(S, excel_file, 'Sheet', sheet_sum, 'WriteRowNames', true, 'Range', 'A1');

fprintf('\nAll data saved to %s\n', excel_file);
