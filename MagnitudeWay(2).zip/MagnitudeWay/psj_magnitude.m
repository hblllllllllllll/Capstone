%% Dual-Channel ADC: ch0 = mixer_LPF_out, ch1 = Vtune
% Connection: mixer_LPF_out → AI0,  Vtune → AI2,  GND → AGND
clear; clc;

%% ===== Parameters (modifiable) =====
boardID        = "Board0";
ai_ch_mix      = "ai0";      % ch0: Mixer + LPF output
ai_ch_vtune    = "ai2";      % ch1: Vtune (used for segmentation)
Fs             = 3.33e5;        % Sampling rate (two channels: ≤ 500 kS/s)
captureTime    = 0.15;     % Acquisition duration (s), should cover multiple sweeps
cuowu = 0;
total_running_times = 0;

% ==== NEW: Cancel smoothing and change to extreme value segmentation + head and tail clipping ====
min_sweep_len  = 2;         % Minimum segment length (samples) to avoid false triggers (half-sweep)
pad_mult       = 4;          % Zero-padding multiplier for FFT
n_peaks        = 6;          % Number of peaks to extract per segment
trim_mode      = 'frac';     % 'frac' or 'samples'
trim_head      = 0.15;       % cut head
trim_tail      = 0.12;       % cut tail

% show one frequency
seg_idx_to_show = [];        % 1,2,3,...choose one

%% ===== FMCW params for distance axis (from your screenshot) =====
VCO_Max_Freq    = 2.25e9;   % [Hz]
VCO_Min_Freq    = 2.09e9;   % [Hz]
Vtune_Freq      = 9e3;      % [Hz]
Vtune_DutyCycle = 0.9;      % duty of up-sweep
VF              = 0.65;     % cable velocity factor
c               = 3e8;      % [m/s]

B    = VCO_Max_Freq - VCO_Min_Freq;      % [Hz] sweep bandwidth
T    = 1 / Vtune_Freq;                    % [s]  period
T_up = T * Vtune_DutyCycle;               % [s]  up-sweep duration
S    = B / T_up;                          % [Hz/s] sweep slope
c_eff = VF * c;                           % [m/s] effective wave speed

%% ===== DAQ Configuration =====
dq = daq("mcc");
addinput(dq, boardID, ai_ch_mix,   "Voltage");  % AI0
addinput(dq, boardID, ai_ch_vtune, "Voltage");  % AI2
dq.Rate = Fs;

%% ===== Data Acquisition =====
data = read(dq, seconds(captureTime));
t    = seconds(data.Time);
y0   = data{:,1};   % ch0: mixer_LPF_out
y1   = data{:,2};   % ch1: Vtune

% Remove DC offset
y0 = y0 - mean(y0);
y1 = y1 - mean(y1);

%% ===== 数字带阻滤波：9 kHz 窄带陷波（IIR + 零相位）=====
f0    = 7e3;      % 陷波中心频率 (Hz)
bwHz  = 6000;      % 陷波带宽 (Hz)，例如 ±100 Hz；可调 50~400 看抑制/旁瓣折中
W0    = f0 / (Fs/2);       % 归一化中心频率 (相对 Nyquist)
BW    = bwHz / (Fs/2);     % 归一化带宽
[b,a] = iirnotch(W0, BW);  % 二阶陷波器

% 零相位双向滤波：避免相位失真
y0_f = filtfilt(b, a, y0);
f0    = 10e3;      % 陷波中心频率 (Hz)
bwHz  = 6000;      % 陷波带宽 (Hz)，例如 ±100 Hz；可调 50~400 看抑制/旁瓣折中
W0    = f0 / (Fs/2);       % 归一化中心频率 (相对 Nyquist)
BW    = bwHz / (Fs/2);     % 归一化带宽
[b,a] = iirnotch(W0, BW);  % 二阶陷波器
y0_f = filtfilt(b, a, y0_f);

f0    = 4e3;      % 陷波中心频率 (Hz)
bwHz  = 1000;      % 陷波带宽 (Hz)，例如 ±100 Hz；可调 50~400 看抑制/旁瓣折中
W0    = f0 / (Fs/2);       % 归一化中心频率 (相对 Nyquist)
BW    = bwHz / (Fs/2);     % 归一化带宽
[b,a] = iirnotch(W0, BW);  % 二阶陷波器
y0_f = filtfilt(b, a, y0_f);

f0    = 6e3;      % 陷波中心频率 (Hz)
bwHz  = 6000;      % 陷波带宽 (Hz)，例如 ±100 Hz；可调 50~400 看抑制/旁瓣折中
W0    = f0 / (Fs/2);       % 归一化中心频率 (相对 Nyquist)
BW    = bwHz / (Fs/2);     % 归一化带宽
[b,a] = iirnotch(W0, BW);  % 二阶陷波器
y0_f = filtfilt(b, a, y0_f);

% ===== 高通参数 =====
fc   = 21e3;           % 截止频率(Hz)：把它左侧的频率滤掉
ord  = 6;             % 滤波器阶数：越高过渡越陡（2~8 合理）
Wc   = fc/(Fs/2);     % 归一化

[b,a] = butter(ord, Wc, 'high');
y0_f = filtfilt(b,a,y0_f);   % 零相位，避免相位失真

fc   = 5e3;           % 截止频率(Hz)：把它左侧的频率滤掉
ord  = 8;             % 滤波器阶数：越高过渡越陡（2~8 合理）
Wc   = fc/(Fs/2);     % 归一化

[b,a] = butter(ord, Wc, 'high');
y0_f = filtfilt(b,a,y0_f);   % 零相位，避免相位失

%% ===== Find segment boundaries using raw Vtune extrema (both rising & falling) =====
[~, locs_max] = findpeaks( y1, 'MinPeakDistance', min_sweep_len);
[~, locs_min] = findpeaks(-y1, 'MinPeakDistance', min_sweep_len);
locs = sort([locs_max; locs_min]);

N = numel(y1);
locs = locs(locs > 1 & locs < N);

seg_starts = [];
seg_ends   = [];
seg_type   = strings(0);  % "up" / "down"

for k = 1:numel(locs)-1
    s = locs(k);
    e = locs(k+1) - 1;
    if e - s + 1 >= min_sweep_len
        seg_starts(end+1) = s;
        seg_ends(end+1)   = e;
        if y1(locs(k+1)) > y1(locs(k))
            seg_type(end+1) = "up";    % rising
        else
            seg_type(end+1) = "down";  % falling
        end
    end
end

%% only up
up_mask    = (seg_type == "up");
seg_starts = seg_starts(up_mask);
seg_ends   = seg_ends(up_mask);
seg_type   = seg_type(up_mask);
numSweeps  = numel(seg_starts);

%% ===== Visualization: time domain + UP boundaries only =====
figure;
subplot(2,1,1);
plot(t, y1); grid on;
title('Vtune (raw, extrema boundaries, UP-only)'); xlabel('Time (s)'); ylabel('V');
hold on;
for k = 1:numSweeps
    xline(t(seg_starts(k)), '--');
end
hold off;

subplot(2,1,2);
plot(t, y0_f); grid on;
title('Mixer LPF Output (ch0) — UP-only segments'); xlabel('Time (s)'); ylabel('V');
hold on;
for k = 1:numSweeps
    xline(t(seg_starts(k)), '--');
end
hold off;

%% ===== Per-segment processing: trimming + windowing + FFT + peak detection (UP-only) =====
peakFreqs_perSweep  = cell(numSweeps,1);
peakAmpsdB_perSweep = cell(numSweeps,1);

if numSweeps > 0
    % Estimated maximum segment length after clipping
    trimmed_lengths = zeros(numSweeps,1);
    for k = 1:numSweeps
        Lraw = seg_ends(k) - seg_starts(k) + 1;
        switch lower(trim_mode)
            case 'frac'
                cutH = floor(Lraw * trim_head);
                cutT = floor(Lraw * trim_tail);
            case 'samples'
                cutH = round(trim_head);
                cutT = round(trim_tail);
            otherwise
                error('trim_mode should be ''frac'' 或 ''samples''');
        end
        a = seg_starts(k) + max(0,cutH);
        b = seg_ends(k)   - max(0,cutT);
        trimmed_lengths(k) = max(0, b - a + 1);
    end
    maxSegLen = max(max(trimmed_lengths), min_sweep_len);
    Npad = 2^nextpow2(maxSegLen * pad_mult);

    % Frequency axis (only positive frequency, excluding DC)
    freq = Fs*(0:Npad-1)/Npad;
    halfMask = 2:floor(Npad/2);
    freqHalf = freq(halfMask);


    % ★ 新增：记录每段的 Xk 与 Mag（半谱，去 DC）
    XkHalfMatrix  = complex(zeros(numSweeps, numel(freqHalf)));
    MagHalfMatrixLin  = zeros(numSweeps, numel(freqHalf));   % ★ 预分配线性幅度
    MagHalfMatrix = zeros(numSweeps, numel(freqHalf));
    specMatrix = zeros(numSweeps, numel(freqHalf));

    for k = 1:numSweeps
        s_idx = seg_starts(k);
        e_idx = seg_ends(k);

        % === Cut the beginning and end of the segment ===
        Lraw = e_idx - s_idx + 1;
        switch lower(trim_mode)
            case 'frac'
                cutH = floor(Lraw * trim_head);
                cutT = floor(Lraw * trim_tail);
            case 'samples'
                cutH = round(trim_head);
                cutT = round(trim_tail);
        end
        a = s_idx + max(0,cutH);
        b = e_idx - max(0,cutT);

        % If over-cutting results in insufficient length, try loosening it to meet the minimum length
        if b - a + 1 < min_sweep_len
            spare = floor((cutH+cutT)/2);
            a = max(s_idx, a - spare);
            b = min(e_idx, b + spare);
        end
        if b <= a
            specMatrix(k,:) = -inf;
            peakFreqs_perSweep{k}  = [];
            peakAmpsdB_perSweep{k} = [];
            continue;
        end

        xk = y0_f(a:b);
        xk = xk - mean(xk);             % Remove DC within the segment

        Nk = length(xk);
        win = hann(Nk,'periodic');
        xw = xk .* win;

        % Zero-padding / truncate to Npad
        if Nk < Npad
            xw_pad = [xw; zeros(Npad - Nk, 1)];
        else
            xw_pad = xw(1:Npad);
        end

        % FFT
        Xk  = fft(xw_pad);
        Mag = 20*log10(abs(Xk) + eps);

        % Save the magnitude spectrum (positive frequency, DC removed)
        % ★ 新增：半谱（去 DC）
        Xk_half = Xk(halfMask).';
        Mag_half_lin = abs(Xk_half);
        Mag_half = 20*log10(abs(Xk_half) + eps);

        % 保存（与原 specMatrix 保持一致）
        XkHalfMatrix(k,:)  = Xk_half;
        MagHalfMatrix(k,:) = Mag_half;
        MagHalfMatrixLin(k,:)  = Mag_half_lin;   % ★ 新增：线性幅度
        specMatrix(k,:)    = Mag_half;
        specMatrix(k,:) = Mag(halfMask).';

        % Peak extraction
        [pk, idx] = findpeaks(specMatrix(k,:), 'SortStr','descend', 'NPeaks', n_peaks);
        peakFreqs_perSweep{k}  = freqHalf(idx);
        peakAmpsdB_perSweep{k} = pk;
    end
else
    % Placeholder when there is no rising edge segment
    Npad = 2^nextpow2(min_sweep_len * pad_mult);
    freq = Fs*(0:Npad-1)/Npad;
    halfMask = 2:floor(Npad/2);
    freqHalf = freq(halfMask);
    specMatrix = zeros(0, numel(freqHalf));
end

%% ===== Print results (main peak per UP segment) =====
fprintf('\n===== Dual-Channel Spectrum Results (UP-only, head/tail trimmed) =====\n');
fprintf('Sampling Rate Fs = %.0f Hz, Duration = %.4f s, UP Segments (valid) = %d\n', Fs, captureTime, numSweeps);
for k = 1:numSweeps
    if ~isempty(peakFreqs_perSweep{k})
        f_main = peakFreqs_perSweep{k}(1);
        a_main = peakAmpsdB_perSweep{k}(1);
        fprintf('UP Segment %d: main peak ~ %.2f kHz, %.1f dB\n', k, f_main/1e3, a_main);
    else
        fprintf('UP Segment %d: no significant peak.\n', k);
    end
end

%% ===== Waterfall plot (spectrum per UP segment) =====
figure;
imagesc(freqHalf/1e3, 1:numSweeps, specMatrix);
axis xy; 
cb = colorbar;              % 创建色条
cb.Label.String = 'Amplitude (dB)';   % 设置色条标题
cb.Label.FontSize = 12;     % 调整字号（可选）
grid on;
xlabel('Frequency (kHz)'); ylabel('Chirp Index (per sweep)');
title('Range–Time Map (Pre-segmented Up-chirp Spectrum)');

%% ===== Waterfall plot (spectrum per UP segment) — X axis as Distance =====
% Map the beat frequency axis to the distance axis: L = (f_b * c_eff) / S
distHalf = (freqHalf * c_eff) / S;   % [m]

figure;
imagesc(distHalf, 1:numSweeps, specMatrix);
axis xy; 
cb = colorbar;              % 创建色条
cb.Label.String = 'Amplitude (dB)';   % 设置色条标题
cb.Label.FontSize = 12;     % 调整字号（可选）
grid on;
xlabel('Distance (m)'); ylabel('Chirp Index (per sweep)');
title('Range–Time Map (Pre-segmented Up-chirp Spectrum)');

%% ===== Single-segment spectrum (one UP segment, e.g., middle) =====
if numSweeps > 0 && ~isempty(specMatrix)
    valid_rows = find(any(isfinite(specMatrix), 2));
    if isempty(valid_rows)
        warning('There are no valid rising edge segments available, so a single-segment spectrum cannot be output.');
    else
        if isempty(seg_idx_to_show)
            seg_pick = valid_rows(ceil(numel(valid_rows)/2));  % Take the "middle valid UP segment"
        else
            seg_pick = seg_idx_to_show;
            if seg_pick < 1 || seg_pick > numSweeps || ~ismember(seg_pick, valid_rows)
                [~, nearestIdx] = min(abs(valid_rows - min(max(seg_pick,1), numSweeps)));
                seg_pick = valid_rows(nearestIdx);
                warning('seg_idx_to_show Invalid, has been changed to the nearest valid UP segment %d。', seg_pick);
            end
        end

        freq_oneSeg_kHz = freqHalf/1e3;
        mag_oneSeg_dB   = specMatrix(seg_pick, :);

        figure;
        plot(freq_oneSeg_kHz, mag_oneSeg_dB); grid on;
        xlabel('Frequency (kHz)'); ylabel('Magnitude (dB)');
        title(sprintf('Single-Segment Spectrum: UP segment %d', seg_pick));

        assignin('base', 'seg_pick',        seg_pick);
        assignin('base', 'freq_oneSeg_kHz', freq_oneSeg_kHz);
        assignin('base', 'mag_oneSeg_dB',   mag_oneSeg_dB);
    end
end


%% ===== Compute residual errors using (I - P) from Excel =====
% 配置：把这三项改成你自己的文件/Sheet 名
ip_excel_file   = 'data6_magnitude.xlsx';              % 保存 I-P 实部的 Excel
ip_sheet_real   = 'IminusP_real';      % I-P 实部 sheet

% 读取并合并为复数矩阵 (63×63)
IminusP6 = readmatrix(ip_excel_file, 'Sheet', ip_sheet_real);
assert(isequal(size(IminusP6), [63 63]), 'I-P 尺寸必须是 63×63');

ip_excel_file8   = 'data8_magnitude.xlsx';              % 保存 I-P 实部的 Excel
ip_sheet_real8   = 'IminusP_real';      % I-P 实部 sheet

% 读取并合并为复数矩阵 (63×63)
IminusP8 = readmatrix(ip_excel_file8, 'Sheet', ip_sheet_real8);
assert(isequal(size(IminusP8), [63 63]),'I-P 尺寸必须是 63×63');

ip_excel_file12   = 'data12_magnitude.xlsx';              % 保存 I-P 实部的 Excel
ip_sheet_real12   = 'IminusP_real';      % I-P 实部 sheet

% 读取并合并为复数矩阵 (63×63)
IminusP12 = readmatrix(ip_excel_file12, 'Sheet', ip_sheet_real12);
assert(isequal(size(IminusP12), [63 63]),'I-P 尺寸必须是 63×63');

ip_excel_file14   = 'data14_magnitude.xlsx';       % 保存 I-P 实部的 Excel
ip_sheet_real14   = 'IminusP_real';      % I-P 实部 sheet

% 读取并合并为复数矩阵 (63×63)
IminusP14 = readmatrix(ip_excel_file14, 'Sheet', ip_sheet_real14);
assert(isequal(size(IminusP14), [63 63]),'I-P 尺寸必须是 63×63');

% 从每个 UP 段的 FFT 半谱中截取 63 个频点，拼成 63×k 的复数矩阵
% 说明：这里默认从半谱的起始处取 63 个 bin。若你有特定的 ROI，请把 startBin 改成对应起点。
if numSweeps == 0
    warning('没有有效的 UP 段，无法计算误差。');
else
    binCount = 63;
    startBin = 1;                               % 可改：你的 ROI 起始 bin（>=1）
    totalHalfBins = numel(freqHalf);            % 半谱长度
    assert(startBin + binCount - 1 <= totalHalfBins, ...
        '半谱长度不足以截取 63 个 bin，请调整 startBin 或 FFT 设置');

    idx63 = startBin : (startBin + binCount - 1);   % 63 个 bin 的索引（半谱坐标）

    % 组装 Xk_63xk：每列是一个 UP 段的复数半谱切片（长度 63）
    Xk_63xk = complex(zeros(63, numSweeps));
    valid_cnt = 0;
    for kseg = 1:numSweeps
        % 这里用前面保存的 XkHalfMatrix（每段的半谱复数，行向量）
        % 若你的 XkHalfMatrix 变量名不同，请相应替换
        x_half = MagHalfMatrixLin(kseg, :);         % 1×(halfBins)，复数
        if any(isfinite(x_half))
            valid_cnt = valid_cnt + 1;
            Xk_63xk(:, valid_cnt) = x_half(idx63).';   % 取 63 个 bin，列向量
        end
    end
    if valid_cnt == 0
        warning('所有段的半谱均无有效数据，无法计算误差。');
    else
        Xk_63xk = Xk_63xk(:, 1:valid_cnt);      % 只保留有效列

        % 与 (I-P) 相乘得到 63×k 的误差矩阵
        E6 = IminusP6 * Xk_63xk;             % IminusP: 63×63（复数）
        E8 = IminusP8 * Xk_63xk;  
        E12 = IminusP12 * Xk_63xk;  
        E14 = IminusP14 * Xk_63xk;  
        
        % 按列求 2-范数并取平均
        errs6 = vecnorm(E6, 2, 1);           % 1×k，每列一个 ||e||_2
        errs8 = vecnorm(E8, 2, 1); 
        errs12 = vecnorm(E12, 2, 1); 
        errs14 = vecnorm(E14, 2, 1); 

        avg_err6  = mean(errs6);
        avg_err8  = mean(errs8);
        avg_err12 = mean(errs12);
        avg_err14 = mean(errs14);

        fprintf('平均误差: e6=%.4f, e8=%.4f, e12=%.4f, e14=%.4f\n', ...
            avg_err6, avg_err8, avg_err12, avg_err14);

        for t = 1:numSweeps
            e6 = errs6(t);
            e8 = errs8(t);
            e12 = errs12(t);
            e14 = errs14(t);
            total_running_times = total_running_times + 1;
            % Case 1: minimum is e6
            %{
            if e8 < e6 || e12<e6 ||e14<e6
               cuowu = cuowu + 1;
            end
            %}

            % Case 2: minimum is e8
            %{
            if e6 < e8 || e12< e8 ||e14<e8
               cuowu = cuowu + 1;
            end
            %}
            % Case 3: minimum is e12
            %{
            if e6 < e12 || e8 < e12 || e14 < e12
               cuowu = cuowu + 1;
            end
            %}
            % Case 4: minimum is e14
            % %{
            if e6 < e14 || e8 < e14 || e12 < e14
               cuowu = cuowu + 1;
            end
            % %}
        end

    end
end

