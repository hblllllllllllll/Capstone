%% build_V_and_IminusP_from_data6.m
% Read 178×63 complex text -> Normalize by row -> Average -> Renormalize -> Obtain V(63×1)
% Calculate P and I-P, and write them back to Excel (separate tables for real and imaginary parts)

%% ========== Configuration ==========
filename  = 'data14_magnitude.xlsx';       % Excel File
sheetName = 'data';                  
nRows     = 178;                
nCols     = 63;               

% Exported Sheet name
sheet_V_real       = 'V_real';
sheet_IminusP_real = 'IminusP_real';
sheet_P_real       = 'P_real';   

%% ========== Read and parse real numbers ==========
C = readcell(filename, 'Sheet', sheetName);
% The data area of ​​nRows×nCols before interception (if the table is larger)
C = C(1:nRows, 1:nCols);

X = complex(nan(nRows,nCols));   % complex matrix
for i = 1:nRows
    for j = 1:nCols
        val = C{i,j};
        if isnumeric(val) && ~isnan(val)
            X(i,j) = complex(val,0);
        elseif ischar(val) || isstring(val)
            s = strtrim(string(val));
            if s == "" || strcmpi(s,"NaN")
                X(i,j) = NaN;
            else
                s2 = strrep(s,' ','');    % remove spaces
                s2 = strrep(s2,'j','i');  % compatible with j
                z  = str2num(s2); 
                if isempty(z)
                    X(i,j) = NaN;
                else
                    X(i,j) = z;
                end
            end
        else
            X(i,j) = NaN;
        end
    end
end

% Check for missing
if any(isnan(X(:)))
    error('The data contains NaNs. Please check for empty cells/formats, or clean the data in Excel first.');
end
%% ========== change to magnitude ==========
X = abs(X);   % Modulo: 178×63, all non-negative real numbers

%% ========== L2 normalization is performed row by row (per sample) ==========
% Each row is a 1×63 vector
rowNorms = vecnorm(X, 2, 2);          % 178×1
idx = (rowNorms > 0);
X(idx,:) = X(idx,:) ./ rowNorms(idx);  % Row normalization: preserve the spectral shape and only scale the total energy

%% ========== Average and then do L2 normalization ==========
v_mean = mean(X, 1);                   % 1×63（real）
n_v    = norm(v_mean,2);
if n_v > 0
    v_mean = v_mean / n_v;             
end
V = v_mean.';                           % 63×1, note that .' is used to perform transposition without taking conjugate

%% ========== Calculate P and I-P ==========
% Conjugate transpose uses ' （Hermitian）
den = (V' * V);                         % Scalar（>0）
if abs(den) < eps
    error('The norm of V is close to 0 and the projection matrix cannot be constructed.');
end
P = (V * V') / den;                     % 63×63，equivalent to V*( (V'*V)\V' )
IminusP = eye(nCols) - P;               % 63×63

%% ========== Write back to Excel (real parts) ==========
% V
writematrix(V, filename, 'Sheet', sheet_V_real, 'Range','A1');

% P
writematrix(P, filename, 'Sheet', sheet_P_real, 'Range','A1');

% I-P
writematrix(IminusP, filename, 'Sheet', sheet_IminusP_real, 'Range','A1');
%% ========== Message ==========
fprintf('Done: The magnitude versions of V, P, and I-P have been generated and written back to Excel.\n');
fprintf('V goes to Sheet: %s\n', sheet_V_real);
fprintf('I-P goes to Sheet: %s\n', sheet_IminusP_real);
